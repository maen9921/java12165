package com.company;


import oracle.jdbc.pool.OracleDataSource;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Collections;
import java.util.List;
import  java.util.ArrayList;


public class Main {

    static String username="fact_sfm";
    static String password="fact_sfm";
    static String con_String="jdbc:oracle:thin:@172.20.5.63:1521:MBDB";
    public static void main(String[] args) {

        try{

            String connString="jdbc:oracle:thin:@172.20.5.63:1521:MBDB";

            OracleDataSource ods = new OracleDataSource();
            ods.setURL(connString);
            ods.setUser("fact_sfm");
            ods.setPassword("fact_sfm");
            Connection con= ods.getConnection();
            Statement conn=con.createStatement();
            java.util.ArrayList<Employee> Employees=new java.util.ArrayList<Employee>();

            ResultSet rs=conn.executeQuery("select * from \"Employees\"");
//            rs.last();
            while (rs.next()) {
                Employee emp=new Employee();
               emp.ID=rs.getInt("ID");
                final String FirstName=rs.getString("First Name");
                final String LastName=rs.getString("Last Name");
                final double Salary=rs.getDouble("Salary");
                final int Age=rs.getInt("Age");
                final String Address=rs.getString("Address");
           Employees.add(emp);






//                System.out.println(rs.getString(6));

//                DatabaseMetaData dbmd = con.getMetaData();
//                System.out.println("Driver Name:" +dbmd.getDriverName() );
//                System.out.println("Driver Version:" +dbmd.getDriverVersion() );
//                System.out.println("User Name:" +dbmd.getUserName() );
//                System.out.println("Database URL:" +dbmd.getURL() );
//                System.out.println("Database Product Name:" +dbmd.getDatabaseProductName() );
//                System.out.println("Databse Product Version:" +dbmd.getDatabaseProductVersion() );


            }



            System.out.println(Employees.stream().count());

//            System.out.println("DONE");
        }catch(Exception e){
            System.out.println(e);}

    }
}
