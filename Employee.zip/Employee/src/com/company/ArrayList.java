package com.company;

import java.util.List;

public class ArrayList {
    public static void main(String[] args) {
        List<Employee> Employees=new java.util.ArrayList<Employee>();

    }
}
