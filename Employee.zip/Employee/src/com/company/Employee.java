package com.company;
import java.util.ArrayList;
public class Employee {
    public int ID;
    public String FirstName;
    public String LastName;
    public double Salary;
    public int Age;
    public String Adderss;

    public void Insert_dat()
    {
//        ArrayList <Employee> a=new ArrayList <Employee>();
//        for (int i=0;i<5;i++)
//        {
//            Employee A
//        }


    }


}
