package com.company;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeeRepo {

    private final Connection connection;

    public EmployeeRepo(Connection connection) {
        this.connection = connection;
    }

    public List<Employee> getMaxSalary() {
        final ResultSet result = executeQuery("SELECT * FROM employee WHERE salary =  (SELECT max(salary) FROM employee)");
        return mapEmployees(result);
    }

    public List<Employee> getMinSalary() {
        final ResultSet result = executeQuery("SELECT * FROM employee WHERE salary =  (SELECT min(salary) FROM employee)");
        return mapEmployees(result);
    }

    public List<Employee> getEmployeeBySalary(final Double salary) {
        final ResultSet result = executeQuery("SELECT * FROM employee WHERE salary = " + salary);
        return mapEmployees(result);
    }

    public List<Employee> getEmployeeLessThanSalary(final Double salary) {
        final ResultSet result = executeQuery("SELECT * FROM employee WHERE salary < " + salary);
        return mapEmployees(result);
    }

    public List<Employee> getEmployeeOlderThanAge(final Integer age) {
        final ResultSet result = executeQuery("SELECT * FROM employee WHERE age > " + age);
        return mapEmployees(result);
    }

    public void deleteEmployeeByFirstName(final String firstName) {
        try {
            final Statement statement = connection.createStatement();
            statement.executeUpdate("DELETE FROM employee WHERE firstName = " + firstName);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    private ResultSet executeQuery(final String sql) {
        try {
            final Statement statement = connection.createStatement();
            return statement.executeQuery(sql);
        } catch (SQLException throwables) {
            throw new RuntimeException(throwables);
        }
    }

    private List<Employee> mapEmployees(ResultSet result) {
        try {
            List<Employee> employees = new ArrayList<>();
            while (result.next()) {
                employees.add(toEmployee(result));
            }
            return employees;
        } catch (SQLException throwables) {
            throw new RuntimeException(throwables);
        }
    }

    private Employee toEmployee(ResultSet result) {
        try {
            if (result.wasNull()) {
                return null;
            }
            final int id = result.getInt("id");
            final String firstName = result.getString("firstName");
            final String lastName = result.getString("lastName");
            final Double salary = result.getDouble("salary");
            final Integer age = result.getInt("age");
            final String address = result.getString("address");
            return new Employee(id, firstName, lastName, salary, age, address);
        } catch (SQLException throwables) {
            throw new RuntimeException(throwables);
        }
    }
}
