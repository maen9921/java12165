package com.company;

public class Main {

    public static void main(String[] args) {

        EmployeeRepo employeeRepo = new EmployeeRepo(Connectivity.getConnection());

        System.out.println("------------------Max Salary------------------");
        System.out.println(employeeRepo.getMaxSalary());

        System.out.println("------------------Min Salary------------------");
        System.out.println(employeeRepo.getMinSalary());

        System.out.println("-------Employees When Salary equal to 400------");
        System.out.println(employeeRepo.getEmployeeBySalary(400D));

        System.out.println("-------Employees When Salary less than 1200------");
        System.out.println(employeeRepo.getEmployeeLessThanSalary(1200D));

        System.out.println("--------------Employees Older than 20------------");
        System.out.println(employeeRepo.getEmployeeOlderThanAge(20));

        Connectivity.close();
    }
}
